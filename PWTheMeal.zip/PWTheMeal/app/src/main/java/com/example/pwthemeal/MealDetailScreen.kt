package com.example.pwthemeal

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberImagePainter
import com.example.pwthemeal.model.Meal
import com.example.pwthemeal.model.MealDetailViewModel // Assicurati di importare il tuo ViewModel corretto


@Composable
fun MealDetailScreen(mealId: String, viewModel: MealDetailViewModel) {
    val meal by viewModel.meal.collectAsState()
    val isLoading = remember { mutableStateOf(true) }
    val error = remember { mutableStateOf<String?>(null) }

    LaunchedEffect(mealId) {
        try {
            viewModel.fetchMealDetails(mealId)
            isLoading.value = false
        } catch (e: Exception) {
            error.value = "Errore nel caricamento dei dettagli"
            isLoading.value = false
        }
    }

    when {
        isLoading.value -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        error.value != null -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = error.value ?: "Errore sconosciuto", color = Color.Red)
            }
        }
        meal != null -> {
            MealDetailContent(meal = meal!!)
        }
        else -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = "Pasto non trovato", color = Color.Red)
            }
        }
    }
}


@Composable
fun MealDetailContent(meal: Meal) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp), // Padding intorno al contenuto
        horizontalAlignment = Alignment.CenterHorizontally // Centra orizzontalmente
    ) {
        // Immagine del pasto
        Image(
            painter = rememberImagePainter(meal.strMealThumb),
            contentDescription = meal.strMeal,
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp), // Altezza dell'immagine
            contentScale = ContentScale.Crop // Adatta l'immagine senza distorsioni
        )

        // Spazio tra l'immagine e il testo
        Spacer(modifier = Modifier.height(16.dp))

        // Nome del pasto
        Text(text = meal.strMeal, fontSize = 24.sp, color = Color.Black)

        // Spazio tra il nome e la categoria
        Spacer(modifier = Modifier.height(8.dp))

        // Categoria del pasto
        Text(text = "Categoria: ${meal.strCategory}", fontSize = 18.sp, color = Color.Gray)

        // Spazio tra la categoria e le istruzioni
        Spacer(modifier = Modifier.height(8.dp))

        // Titolo per le istruzioni
        Text(
            text = "Istruzioni:",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold // Grassetto per il titolo delle istruzioni
        )

        // Spazio tra il titolo e il testo delle istruzioni
        Spacer(modifier = Modifier.height(4.dp))

        // Istruzioni per preparare il pasto
        Text(text = meal.strInstructions, fontSize = 16.sp, color = Color.Black)
    }
}

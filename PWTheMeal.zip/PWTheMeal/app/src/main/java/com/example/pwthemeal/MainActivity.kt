package com.example.pwthemeal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.pwthemeal.model.MealViewModel
import com.example.pwthemeal.ui.theme.PWTheMealTheme
import com.example.pwthemeal.model.MealDetailViewModel  // Usa il MealDetailViewModel corretto


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PWTheMealTheme {
                AppNavigator()  // Non c'è bisogno di usare un tipo generico
            }
        }
    }
}

@Composable
fun AppNavigator() {  // Rimuovi il tipo generico
    val navController = rememberNavController()
    NavHost(navController, startDestination = "welcome") {
        composable("welcome") {
            WelcomeScreen(navController)
        }
        composable("home") {
            HomeScreen(navController)
        }
        composable("mealsList/{category}") { backStackEntry ->
            val category = backStackEntry.arguments?.getString("category") ?: ""
            MealsListScreen(navController, category)
        }
        composable("mealDetail/{mealId}") { backStackEntry ->
            val mealId = backStackEntry.arguments?.getString("mealId") ?: ""
            val mealDetailViewModel: MealDetailViewModel = viewModel()  // Usa il ViewModel corretto
            MealDetailScreen(
                mealId = mealId,
                viewModel = mealDetailViewModel  // Passa il ViewModel
            )
        }
    }
}

@Composable
fun WelcomeScreen(navController: NavController) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFFAF3E0)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Benvenuto su TheMealApp",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = { navController.navigate("home") },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800))
            ) {
                Text(text = "Entra", fontSize = 18.sp, color = Color.White)
            }
        }
    }
}

@Composable
fun HomeScreen(navController: NavController) {
    // Ottieni il ViewModel all'interno della funzione composable
    val mealViewModel: MealViewModel = viewModel()

    // Osserva lo stato delle categorie
    val categories by mealViewModel.categories.collectAsState()

    // Effettua il fetch delle categorie
    LaunchedEffect(Unit) {
        mealViewModel.fetchCategories()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Scegli una categoria:", fontSize = 22.sp, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(20.dp))

            // Visualizza la lista delle categorie con LazyColumn
            LazyColumn {
                items(categories) { category ->
                    CategoryButton(
                        text = category.strCategory,
                        color = Color(0xFF4CAF50)
                    ) {
                        navController.navigate("mealsList/${category.strCategory}")
                    }
                }
            }
        }
    }
}


@Composable
fun CategoryButton(text: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color),
        modifier = Modifier
            .padding(vertical = 5.dp)
            .width(200.dp)
    ) {
        Text(text = text, fontSize = 18.sp, color = Color.White)
    }
}

package com.example.pwthemeal.model

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pwthemeal.network.MealApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MealDetailViewModel : ViewModel() {
    private val _meal = MutableStateFlow<Meal?>(null)
    val meal: StateFlow<Meal?> get() = _meal

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> get() = _error

    fun fetchMealDetails(mealId: String) {
        viewModelScope.launch {
            try {
                val response = MealApi.retrofitService.getMealDetails(mealId)
                if (response.meals.isNullOrEmpty()) {
                    _meal.value = null
                    _error.value = "Dettagli del pasto non disponibili"
                } else {
                    _meal.value = response.meals?.firstOrNull()
                    _error.value = null
                }
            } catch (e: Exception) {
                _meal.value = null
                _error.value = "Errore nel caricamento dei dettagli"
            }
        }
    }
}

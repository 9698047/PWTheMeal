package com.example.pwthemeal.network

import com.example.pwthemeal.model.MealResponse
import com.example.pwthemeal.CategoriesResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface MealApiService {

    // Ottieni i pasti per categoria
    @GET("filter.php")
    suspend fun getMealsByCategory(@Query("c") category: String): MealResponse

    // Ottieni tutti i pasti di un determinato pasto
    @GET("lookup.php")
    suspend fun getMealDetails(@Query("i") mealId: String): MealResponse

    // Ottieni tutte le categorie
    @GET("categories.php")
    suspend fun getCategories(): CategoriesResponse
}

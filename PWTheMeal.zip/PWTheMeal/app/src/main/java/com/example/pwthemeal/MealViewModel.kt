package com.example.pwthemeal.model

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pwthemeal.Category
import com.example.pwthemeal.network.MealApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MealViewModel : ViewModel() {
    private val _meals = MutableStateFlow<List<Meal>>(emptyList()) // La lista dei pasti
    val meals: StateFlow<List<Meal>> get() = _meals
    // Questa è la proprietà che tiene traccia delle categorie
    private val _categories = MutableStateFlow<List<Category>>(emptyList())  // Categoria è un tipo che dovrai definire
    val categories: StateFlow<List<Category>> get() = _categories

    // Metodo per recuperare le categorie da un'API o una fonte di dati
    fun fetchCategories() {
        viewModelScope.launch {
            try {
                val response = MealApi.retrofitService.getCategories() // Presupponiamo che questa funzione esista nell'API
                _categories.value = response.categories ?: emptyList()  // Imposta la lista di categorie
            } catch (e: Exception) {
                e.printStackTrace()
                _categories.value = emptyList()  // Se c'è un errore, imposta la lista come vuota
            }
        }
    }
    fun fetchMeals(category: String) {
        viewModelScope.launch {
            try {
                // Supponiamo che MealApi abbia un metodo getMeals
                val response = MealApi.retrofitService.getMealsByCategory(category)
                _meals.value = response.meals ?: emptyList() // Assegna i pasti ricevuti
            } catch (e: Exception) {
                e.printStackTrace()
                _meals.value = emptyList() // Se errore, lista vuota
            }
        }
    }
}

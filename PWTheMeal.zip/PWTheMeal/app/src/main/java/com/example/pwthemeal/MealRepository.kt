package com.example.pwthemeal

import com.example.pwthemeal.model.MealResponse
import com.example.pwthemeal.CategoriesResponse
import com.example.pwthemeal.network.MealApi
import retrofit2.Response

// MealRepository.kt
class MealRepository {

    // Ottieni i pasti per categoria
    suspend fun getMealsByCategory(category: String): MealResponse {
        return MealApi.retrofitService.getMealsByCategory(category)
    }

    // Ottieni tutte le categorie
    suspend fun getMealCategories(): CategoriesResponse {
        return MealApi.retrofitService.getCategories()
    }

    // Aggiungi una funzione per ottenere i dettagli del pasto
    suspend fun getMealDetails(mealId: String): MealResponse {
        return MealApi.retrofitService.getMealDetails(mealId)
    }
}

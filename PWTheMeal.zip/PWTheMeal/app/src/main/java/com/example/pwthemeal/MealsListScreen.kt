package com.example.pwthemeal

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.rememberImagePainter
import com.example.pwthemeal.model.Meal
import com.example.pwthemeal.model.MealViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MealsListScreen(navController: NavController, category: String) {
    val viewModel: MealViewModel = viewModel()
    val meals by viewModel.meals.collectAsState(emptyList())  // Fallback vuoto se la lista è nulla

    // Carica i pasti della categoria
    LaunchedEffect(category) {
        viewModel.fetchMeals(category)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Ricette di $category") },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFFFF9800) // Cambia il colore della TopBar
                )
            )
        }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues)) {
            // Verifica che la lista dei pasti non sia vuota
            if (meals.isNotEmpty()) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    items(meals) { meal ->
                        MealItem(meal, navController)
                    }
                }
            } else {
                // Mostra un messaggio se la lista è vuota
                Text(text = "Nessun pasto disponibile per questa categoria", modifier = Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
fun MealItem(meal: Meal, navController: NavController) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable {
                // Naviga alla schermata dei dettagli
                navController.navigate("mealDetail/${meal.idMeal}")
            },
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Verifica se la thumb del pasto è nulla o vuota
            val imageUrl = meal.strMealThumb.ifEmpty { "https://via.placeholder.com/200" }
            Image(
                painter = rememberImagePainter(imageUrl),
                contentDescription = meal.strMeal,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(8.dp))
            // Verifica se il nome del pasto è nullo o vuoto
            Text(text = meal.strMeal.ifEmpty { "Pasto senza nome" }, fontSize = 20.sp, color = Color.Black)
        }
    }
}
